self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "68a476fbe139e7951436734373d141c4",
    "url": "./index.html"
  },
  {
    "revision": "2cefcd65d89d7d52848c",
    "url": "./static/css/2.7cc9718e.chunk.css"
  },
  {
    "revision": "2e616082f23a71532e03",
    "url": "./static/css/main.3332da6b.chunk.css"
  },
  {
    "revision": "2cefcd65d89d7d52848c",
    "url": "./static/js/2.a1040659.chunk.js"
  },
  {
    "revision": "f6ce9b198908e234c073cb4697347be2",
    "url": "./static/js/2.a1040659.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2e616082f23a71532e03",
    "url": "./static/js/main.bdea7202.chunk.js"
  },
  {
    "revision": "f5021abe2fadcea5437a",
    "url": "./static/js/runtime-main.328b4e46.js"
  },
  {
    "revision": "8206160193b5ec6de25681d8ed766247",
    "url": "./static/media/4k.82061601.jpg"
  },
  {
    "revision": "1503ac4b8fd6c8d3d340417536ea2176",
    "url": "./static/media/BROKEN.1503ac4b.png"
  },
  {
    "revision": "2114feea092ecbbd17c94bab87536c19",
    "url": "./static/media/Logo.2114feea.png"
  },
  {
    "revision": "13c55a32c57c31520356ab2f5f1d795e",
    "url": "./static/media/NORMAL.13c55a32.png"
  },
  {
    "revision": "57555367659178614a2309dd0356d811",
    "url": "./static/media/coin.57555367.png"
  }
]);